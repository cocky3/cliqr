package org.hermit.audalyzer;

import android.content.Context;
import android.view.SurfaceView;

public class SurfaceGraph extends SurfaceView {

	public SurfaceGraph(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

}
